-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 09 nov. 2023 à 17:39
-- Version du serveur : 8.0.31
-- Version de PHP : 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `chat`
--

-- --------------------------------------------------------

--
-- Structure de la table `chat_user`
--

DROP TABLE IF EXISTS `chat_user`;
CREATE TABLE IF NOT EXISTS `chat_user` (
  `user_name` text NOT NULL,
  `user_id` int NOT NULL,
  `user_full_name` text NOT NULL,
  `user_image` text NOT NULL,
  `user_password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`user_name`(64))
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `chat_user`
--

INSERT INTO `chat_user` (`user_name`, `user_id`, `user_full_name`, `user_image`, `user_password`) VALUES
('Reginald', 3, 'Regald Regis', 'C:\\wamp64\\www\\chat-room-nodejs\\chat-room-nodejs\\app\\images\\Reginald\n', '1234567890'),
('AlphaOmega', 2, 'Alexandre Grosset', 'C:\\wamp64\\www\\chat-room-nodejs\\chat-room-nodejs\\app\\images\\Alexandre', '0987654321'),
('Bobby', 1, 'Bob Gratton', 'C:\\wamp64\\www\\chat-room-nodejs\\chat-room-nodejs\\app\\images\\Bob', '1234567890');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
